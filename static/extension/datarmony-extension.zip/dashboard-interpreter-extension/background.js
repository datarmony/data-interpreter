const DEBUG = true;

function log(...args) {
  if (DEBUG) {
    console.log(...args);
  }
}

function warn(...args) {
  if (DEBUG) {
    console.warn(...args);
  }
}

function error(...args) {
  if (DEBUG) {
    console.error(...args);
  }
}

// This function encapsulates the entire screenshot and processing logic.
async function triggerScreenshotProcess(tab) {
  const tabId = tab.id;
  console.log(`[BACKGROUND.JS] triggerScreenshotProcess called for tab ${tabId}.`);

  if (!tabId) {
    console.error("[BACKGROUND.JS] Could not get active tab ID for screenshot process.");
    return;
  }

  try {
    // 1. Attach the debugger to the tab
    const targets = await new Promise(resolve => chrome.debugger.getTargets(resolve));
    let alreadyAttached = false;
    for (const target of targets) {
        if (target.tabId === tabId && target.attached && target.extensionId === chrome.runtime.id) {
            alreadyAttached = true;
            break;
        }
    }

    if (!alreadyAttached) {
        await new Promise((resolve, reject) => {
          chrome.debugger.attach({ tabId: tabId }, "1.3", () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
    }
    console.log("Debugger attached to tab:", tabId);

    // 2. Get page layout metrics
    const { result: { contentSize } } = await new Promise((resolve, reject) => {
      chrome.debugger.sendCommand(
        { tabId: tabId },
        "Page.getLayoutMetrics",
        {},
        (result) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else if (result.error) {
            reject(new Error(result.error.message));
          } else {
            resolve({ result });
          }
        }
      );
    });
    console.log("Page layout metrics:", contentSize);

    // 3. Capture the screenshot
    const { result: { data } } = await new Promise((resolve, reject) => {
      chrome.debugger.sendCommand(
        { tabId: tabId },
        "Page.captureScreenshot",
        {
          format: "png",
          quality: 90,
          captureBeyondViewport: true,
          fromSurface: true,
          clip: {
            x: 0,
            y: 0,
            width: contentSize.width,
            height: contentSize.height,
            scale: 1
          }
        },
        (result) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else if (result.error) {
            reject(new Error(result.error.message));
          } else {
            resolve({ result });
          }
        }
      );
    });
    console.log("Screenshot captured.");

    // 4. Detach the debugger
    if (!alreadyAttached) {
        await new Promise((resolve, reject) => {
          chrome.debugger.detach({ tabId: tabId }, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
        console.log("Debugger detached.");
    }

    // 5. Send the image to the server
    console.log("Attempting to send screenshot to server...");
    try {
      const response = await fetch('http://192.168.1.147:8001/api/upload_screenshot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image_data: data }),
      });
      console.log(`[DEBUG] Server response status: ${response.status}`);

      if (response.ok) {
        const result = await response.json();
        console.log("[BACKGROUND.JS] Server response received:", result);
        if (result.success && result.gemini_analysis_html && result.gemini_analysis_md) {
            chrome.tabs.sendMessage(tabId, {
                action: "showGeminiAnalysis",
                analysisHtml: result.gemini_analysis_html,
                analysisMd: result.gemini_analysis_md
            }, (responseFromTab) => {
                if (chrome.runtime.lastError) {
                    console.error("[BACKGROUND.JS] Error sending 'showGeminiAnalysis' message:", chrome.runtime.lastError.message);
                } else {
                    console.log("[BACKGROUND.JS] 'showGeminiAnalysis' message sent. Tab responded:", responseFromTab);
                }
            });
        } else {
            const errorMessage = result.message || "Analysis failed or was not returned.";
            const errorPayload = result.gemini_analysis_md || errorMessage;
            console.error("[BACKGROUND.JS] Analysis failed or missing:", errorMessage);
            chrome.tabs.sendMessage(tabId, {
                action: "geminiAnalysisError",
                error: errorPayload
            }, (responseFromTab) => {
                 if (chrome.runtime.lastError) {
                    console.error("[BACKGROUND.JS] Error sending 'geminiAnalysisError' (analysis failed) message:", chrome.runtime.lastError.message);
                } else {
                    console.log("[BACKGROUND.JS] 'geminiAnalysisError' (analysis failed) message sent. Tab responded:", responseFromTab);
                }
            });
        }
      } else {
        const errorText = await response.text();
        console.error(`[BACKGROUND.JS] Server responded with ${response.status}: ${errorText}`);
        chrome.tabs.sendMessage(tabId, {
            action: "geminiAnalysisError",
            error: `Server error ${response.status}: ${errorText.substring(0, 150)}`
        }, (responseFromTab) => {
             if (chrome.runtime.lastError) {
                console.error("[BACKGROUND.JS] Error sending 'geminiAnalysisError' (fetch not ok) message:", chrome.runtime.lastError.message);
            } else {
                console.log("[BACKGROUND.JS] 'geminiAnalysisError' (fetch not ok) message sent. Tab responded:", responseFromTab);
            }
        });
      }
    } catch (serverError) {
      console.error("[BACKGROUND.JS] Error during fetch to /api/upload_screenshot:", serverError);
       chrome.tabs.sendMessage(tabId, {
            action: "geminiAnalysisError",
            error: serverError.message || "Network error contacting server."
       }, (responseFromTab) => {
            if (chrome.runtime.lastError) {
                console.error("[BACKGROUND.JS] Error sending 'geminiAnalysisError' (catch serverError) message:", chrome.runtime.lastError.message);
            } else {
                console.log("[BACKGROUND.JS] 'geminiAnalysisError' (catch serverError) message sent. Tab responded:", responseFromTab);
            }
       });
    }
  } catch (error) {
    console.error("[BACKGROUND.JS] Error during screenshot capture process:", error);
     chrome.tabs.sendMessage(tabId, {
        action: "geminiAnalysisError",
        error: error.message || "Error during screenshot capture."
     }, (responseFromTab) => {
        if (chrome.runtime.lastError) {
            console.error("[BACKGROUND.JS] Error sending 'geminiAnalysisError' (catch main error) message:", chrome.runtime.lastError.message);
        } else {
            console.log("[BACKGROUND.JS] 'geminiAnalysisError' (catch main error) message sent. Tab responded:", responseFromTab);
        }
     });
    // Ensure debugger is detached on error
    const targets = await new Promise(resolve => chrome.debugger.getTargets(resolve));
    for (const target of targets) {
        if (target.tabId === tabId && target.attached && target.extensionId === chrome.runtime.id) {
            chrome.debugger.detach({ tabId: tabId }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Error detaching debugger after failure:", chrome.runtime.lastError.message);
                } else {
                    console.log("Debugger detached after failure.");
                }
            });
            break;
        }
    }
  }
}

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  log("[BACKGROUND.JS] Received external message:", request);

  if (request && typeof request === 'object' && request.action === "captureFromWeb") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
              log("[BACKGROUND.JS] Initiating screenshot process for tab:", tabs[0].id);
              triggerScreenshotProcess(tabs[0]); // Directly call the function
              sendResponse({ status: "started" });
          } else {
              error("[BACKGROUND.JS] No active tab found to initiate screenshot.");
              sendResponse({ status: "error", message: "No active tab found." });
          }
      });
      return true; // Keep channel open for async response

  } else if (typeof request === 'string' && request === 'version') {
      log(`[BACKGROUND.JS] Received 'version' request from sender: ${sender.url || sender.id}`);
      sendResponse({ version: chrome.runtime.getManifest().version });
      return true;

  } else {
       warn("[BACKGROUND.JS] Received unhandled external message or invalid action:", request);
       sendResponse({ status: "error", message: "Unhandled message or invalid action." });
  }
});
 
// Optional: Handle debugger detachment events (e.g., if DevTools is opened manually)
// This listener remains as it's independent of the click action.
chrome.debugger.onDetach.addListener((source, reason) => {
  console.log("Debugger detached.", source, reason);
});