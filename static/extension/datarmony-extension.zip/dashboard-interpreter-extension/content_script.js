// dashboard-interpreter-extension/content_script.js
console.log("[CONTENT_SCRIPT.JS] Loaded and listening for messages from background script.");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[CONTENT_SCRIPT.JS] Received message from background:", message);

  // Filter for the specific actions we want to forward
  if (message.action === "showGeminiAnalysis") {
    // Forward both HTML and MD analysis
    window.postMessage({
      type: "FROM_CONTENT_SCRIPT",
      action: message.action,
      payloadHtml: message.analysisHtml, // HTML for display
      payloadMd: message.analysisMd      // Markdown for download
    }, "*"); 

    console.log("[CONTENT_SCRIPT.JS] Forwarded 'showGeminiAnalysis' message to page via window.postMessage.");
    sendResponse({ status: "analysis_message_forwarded" });

  } else if (message.action === "geminiAnalysisError") {
     // Forward the error message
     window.postMessage({
      type: "FROM_CONTENT_SCRIPT",
      action: message.action,
      payloadError: message.error // Send error text
    }, "*");

    console.log("[CONTENT_SCRIPT.JS] Forwarded 'geminiAnalysisError' message to page via window.postMessage.");
    sendResponse({ status: "error_message_forwarded" });
  } else {
    console.log("[CONTENT_SCRIPT.JS] Ignoring message action:", message.action);
    // Optionally send a response for unhandled actions if needed
    // sendResponse({ status: "action_ignored" });
  }
  // Return true to indicate you wish to send a response asynchronously
  // (required if sendResponse might be called later, good practice even if called synchronously).
  return true;
});